package com.example.scarylock;

import android.app.*; import android.os.*; import android.graphics.*; import android.view.*; import android.content.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 static final String PASSWORD="76742336"; EditText pass;
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(1024,1024); build();}
 void build(){
  FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
  root.addView(new HackerView(this),new FrameLayout.LayoutParams(-1,-1));
  LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(35,20,35,20);
  TextView t=new TextView(this); t.setText("⚠  SYSTEM LOCKED"); t.setTextColor(Color.rgb(255,60,60)); t.setTextSize(27); t.setGravity(17);
  TextView s=new TextView(this); s.setText("SECURE VISUAL TERMINAL\nACCESS REQUIRES PASSWORD"); s.setTextColor(Color.WHITE); s.setGravity(17);
  pass=new EditText(this); pass.setInputType(2); pass.setHint("ENTER PASSWORD"); pass.setTextColor(Color.WHITE); pass.setHintTextColor(Color.LTGRAY); pass.setGravity(17); pass.setTextSize(19);
  Button b=new Button(this); b.setText("AUTHENTICATE"); b.setOnClickListener(v->check());
  box.addView(t);box.addView(s);box.addView(pass,new LinearLayout.LayoutParams(-1,75));box.addView(b);
  FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-2);lp.gravity=17;root.addView(box,lp);setContentView(root); immersive();
 }
 void check(){if(PASSWORD.equals(pass.getText().toString())){Toast.makeText(this,"ACCESS GRANTED",0).show();finish();}else{pass.setText("");Toast.makeText(this,"ACCESS DENIED",0).show();}}
 void immersive(){getWindow().getDecorView().setSystemUiVisibility(5894);}
 public void onBackPressed(){}
 class HackerView extends View{
  Paint p=new Paint(3); Bitmap bg; Random r=new Random(); float scan=0;
  HackerView(Context c){super(c);bg=BitmapFactory.decodeResource(getResources(),R.drawable.user_background);}
  protected void onDraw(Canvas c){
   int w=getWidth(),h=getHeight();
   if(bg!=null){float sc=Math.max((float)w/bg.getWidth(),(float)h/bg.getHeight());float bw=bg.getWidth()*sc,bh=bg.getHeight()*sc;
    c.drawBitmap(bg,null,new RectF((w-bw)/2,(h-bh)/2,(w+bw)/2,(h+bh)/2),p);}
   p.setColor(Color.argb(150,0,0,0));c.drawRect(0,0,w,h,p);
   p.setColor(Color.argb(45,0,255,120));p.setStrokeWidth(1);for(int y=0;y<h;y+=6)c.drawLine(0,y,w,y,p);
   scan+=10;if(scan>h+100)scan=-100;p.setColor(Color.argb(80,0,255,120));c.drawRect(0,scan,w,scan+18,p);
   p.setColor(Color.argb(180,0,255,120));p.setTextSize(12);
   String[] z={"ACCESS_NODE // 01","ENCRYPT_LAYER","TRACE_SIGNAL","DECRYPTING...","TARGET_LOCK","0x7F 0xA1 0xC9"};
   for(int i=0;i<z.length;i++)c.drawText(z[i],12,(scan+i*95)%h,p);
   float cx=w*.52f,cy=h*.37f; p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.argb(210,255,45,45));
   c.drawRect(w*.27f,h*.22f,w*.77f,h*.54f,p);p.setStyle(Paint.Style.FILL);c.drawText("TARGET // SCANNING",w*.27f,h*.22f-10,p);
   p.setStyle(Paint.Style.STROKE);p.setColor(Color.argb(130,0,255,150));float rr=75+(float)(20*Math.sin(System.currentTimeMillis()/220.0));c.drawCircle(cx,cy,rr,p);c.drawCircle(cx,cy,rr+20,p);p.setStyle(Paint.Style.FILL);
   p.setTextSize(12);c.drawText("BIOMETRIC VISUAL SIMULATION",18,h-52,p);c.drawText("NODE: LOCAL // SIGNAL: LOCKED",18,h-30,p);
   postInvalidateDelayed(35);
  }
 }
}
